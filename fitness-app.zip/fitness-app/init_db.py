import sys
import os

# Add the app directory to the system path to find models.py
sys.path.append(os.path.join(os.path.dirname(__file__), 'app'))

from app import app, db  # Import app and db from the app directory

# Initialize the database with the app context
with app.app_context():
    db.create_all()  # Creates all tables
