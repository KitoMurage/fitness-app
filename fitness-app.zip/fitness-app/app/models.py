from flask_sqlalchemy import SQLAlchemy

# Initialize the database object
db = SQLAlchemy()

# User model for database table
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(80), nullable=False)
